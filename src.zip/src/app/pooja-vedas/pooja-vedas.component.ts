import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pooja-vedas',
  templateUrl: './pooja-vedas.component.html',
  styleUrls: ['./pooja-vedas.component.css']
})
export class PoojaVedasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
