import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pooja-geeta',
  templateUrl: './pooja-geeta.component.html',
  styleUrls: ['./pooja-geeta.component.css']
})
export class PoojaGeetaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
