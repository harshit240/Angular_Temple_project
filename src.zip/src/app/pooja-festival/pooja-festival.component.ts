import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pooja-festival',
  templateUrl: './pooja-festival.component.html',
  styleUrls: ['./pooja-festival.component.css']
})
export class PoojaFestivalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
