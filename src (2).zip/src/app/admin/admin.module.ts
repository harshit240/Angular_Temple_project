import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { SliderComponent } from './slider/slider.component';
import { TableComponent } from './table/table.component';


@NgModule({
  declarations: [
    DashboardComponent,
    SidebarComponent,
    SliderComponent,
    TableComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule
  ],
  exports:[DashboardComponent,
  SidebarComponent]
})
export class AdminModule { }
