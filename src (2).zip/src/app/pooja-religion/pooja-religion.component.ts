import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pooja-religion',
  templateUrl: './pooja-religion.component.html',
  styleUrls: ['./pooja-religion.component.css']
})
export class PoojaReligionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
