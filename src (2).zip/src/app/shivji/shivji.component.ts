import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shivji',
  templateUrl: './shivji.component.html',
  styleUrls: ['./shivji.component.css']
})
export class ShivjiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
