import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pooja-temple',
  templateUrl: './pooja-temple.component.html',
  styleUrls: ['./pooja-temple.component.css']
})
export class PoojaTempleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
