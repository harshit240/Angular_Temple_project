import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sec3',
  templateUrl: './sec3.component.html',
  styleUrls: ['./sec3.component.css']
})
export class Sec3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
