import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sec2',
  templateUrl: './sec2.component.html',
  styleUrls: ['./sec2.component.css']
})
export class Sec2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
